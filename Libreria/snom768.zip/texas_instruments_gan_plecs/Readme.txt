Model Version A (Released October 2022)

The PLECS model provided herewith can be used to simulate the TI GaN FET operation in the desired power converter and estimate the FET power losses. This also allows estimation of the FET junction temperature according to the user-specified thermomechanical inputs such as thermal resistance from junction-to-case. Adjustability of the TI GaN FET’s drain-to-source slew-rate during turn-on is enabled with a parameter entry by the user to appropriately model the power loss during hard-switching. Variation of the FET on-resistance and switching losses with junction temperature is modeled in the thermal domain. The integrated protection features of TI GaN products are not modeled.

Three configurations of the model are provided to the user to choose from: 
•	Version 1 (Hard-switching model): This model can be used for any generic hard-switching topology. With this version, conduction and switching losses in the device can be captured along with the thermal behavior. Turn-on slew-rate adjustment is enabled to properly account for overlap losses. In the electrical domain, only the FET on-resistance and reverse voltage drop are modeled.
•	Version 2 (FAST Soft-switching model): Many soft-switching topologies require capacitance of the device to be modeled to understand the zero voltage switching (ZVS) behavior under different electrical environment. This version incorporates the FET’s output capacitance to allow the user to study those ZVS transitions, in addition to the FET on-resistance and reverse voltage drop for the electrical domain. However, power loss modelling is not included in this model in order to enable faster simulation. Hence the FET power loss information cannot be obtained using this version. 
•	Version 3 (SLOW Soft-switching model): This configuration models Coss of the device to study ZVS transitions, the FET on-resistance, reverse voltage drop in the electrical domain and it also incorporates the FET power loss modeling. This version should be used when the user desires to obtain the FET power losses, thermal behavior and ZVS transitions in soft-switching topologies. 

For Versions 1 and 3, the FET must be placed on a heatsink and appropriate values must be specified. Under "Thermal" tab, “initial junction temperature” or “case-to-heatsink thermal resistance” must be entered. Default initial temp=25C, Rth_ch=0.1C/W. 

All the configurations require use of a .xml thermal file, which contains default parameter values. These .xml can be found in the model folder.  You do not need to provide a value for device parameters that show their default values in gray, but you can overwrite these to a different value.

Revision History:
Model version A – initial release

===========================================
This model is designed as an aid for customers of Texas Instruments. 
TI and its licensors and suppliers make no warranties, either expressed 
or implied, with respect to this model, including the warranties of 
merchantability or fitness for a particular purpose. The model is 
provided solely on an "as is" basis. The entire risk as to its quality 
and performance is with the customer. 
===========================================
